smalltalk.initialize();

/* Similar to jQuery(document).ready() */

if(this.smalltalkReady) {
	this.smalltalkReady();
}
